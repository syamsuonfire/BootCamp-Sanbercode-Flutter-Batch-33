import 'titan.dart';

class Human extends Titan {
  String killAllTitan() {
    return "Sasageyo ... Shinzo Sasageyo...";
  }
}
