import 'titan.dart';

class AttackTitan extends Titan {
  String punch() {
    return "Blam... Blam...";
  }
}
