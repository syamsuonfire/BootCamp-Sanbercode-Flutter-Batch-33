import 'titan.dart';

class ArmoredTitan extends Titan {
  String terjang() {
    return "Dush... Dush...";
  }
}
