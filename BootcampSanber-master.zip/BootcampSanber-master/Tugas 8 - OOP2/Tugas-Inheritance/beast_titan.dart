import 'titan.dart';

class BeastTitan extends Titan {
  String lempar() {
    return "Wush... Wush...";
  }
}
