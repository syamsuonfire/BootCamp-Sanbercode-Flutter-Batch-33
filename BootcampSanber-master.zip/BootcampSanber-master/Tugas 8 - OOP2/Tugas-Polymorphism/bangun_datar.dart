class BangunDatar {
  double luas() {
    print('Menghitung Luas Bangun Datar...');
    return 0;
  }

  double keliling() {
    print('Menghitung Keliling Bangun Datar...');
    return 0;
  }
}
