class Employee {
  late int id;
  late String name;
  late String departement;

  Employee(int id, String name, String departement) {
    this.id = id;
    this.name = name;
    this.departement = departement;
  }
}
