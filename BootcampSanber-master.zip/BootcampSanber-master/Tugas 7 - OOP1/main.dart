import 'lingkaran.dart';

void main() {
  Lingkaran data = new Lingkaran();
  data.setR(-10);

  var res = data.luas();
  print(res);
}
