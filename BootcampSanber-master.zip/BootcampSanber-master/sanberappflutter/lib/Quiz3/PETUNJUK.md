# IndonesiaMengoding
# InfoQuiz3

## Silahkan buat folder baru seperti pada pengerjaan tugas dengan nama "Quiz3" 
## di dalam folder project Expo/React Native Anda.

## Masukkan file chatscreen.dart, drwerscreen.dart, homescreen.dart, loginscreen.dart, mainapp.dart ke dalam folder tersebut

## Import / panggil MainApp.dart di main.dart pada root folder project agar bisa ditampilkan pada device/emulator Anda

## Quiz kali ini terdiri dari 3 Soal

## Penjelasan dan lokasi soal dapat dicari pada file LoginScreen.dart dan HomeScreen.dart dan ChatScreen.dart 

## dengan menggunakan fitur search "#Soal" atau "//?" tanpa petik (")



## Berikut daftar soal pada Quiz kali ini

<!-- //? #Soal No. 1 (15poin) -- LoginScreen.dart -- Function LoginScreen
    ? Buatlah sebuah fungsi untuk berpindah halaman di button login apabila di press akan ke halaman HomeScreen.dart


<!-- //? #Soal No 2 (20 poin) -- HomeScreen.js -- Function HomeScreen
    ? Buatlah 1 komponen GridView dengan input berasal dari assets/img yang sudah disediakan
       
    ? dan memiliki 2 kolom, sehingga menampilkan 2 item per baris (horizontal)
    ? untuk tampilan apabila ada warning boleh diabaikan asal data gambar tampil
     --> 

<!--  //? #Soal No 3 (15 poin) -- ChatScreen.dart --
     ? Buatlah ListView widget agar dapat menampilkan list title, subtitle dan trailling, dan styling agar dapat tampil baik di device -->
     

<!--  //? #Bonus (10 poin) -- DrawerScreen.dart --
    ? agar ubahlah gambar pada drawerScreen.dart menjadi individu masing masing, untuk nama dan email juga beri yang dari email yang terdaftar di sanbercode.com -->



## Contoh hasil akhir dari aplikasi dapat dilihat pada link berikut (jenis file .gif):      
## https://www.youtube.com/watch?v=DPRJ5dNx5AA

## Setelah selesai mengerjakan, push pekerjaan Anda ke repository gitlab masing-masing
## Input link commit hasil pekerjaan Anda ke fitur Quiz, Bagian Essay di bawah pilihan ganda atau boleh di taruh di quiz 3 di sanbercode.com 

## Kerjakan soal semampunya dengan baik dan jujur
## Tidak perlu bertanya kepada trainer terkait soal, cukup dikerjakan sesuai pemahaman peserta
## Peserta diperbolehkan untuk googling, namun tidak diperbolehkan untuk bertanya, berdiskusi, atau mencontek.
## Selama quiz berlangsung, grup diskusi telegram akan dinonaktifkan (peserta tidak dapat mengirimkan pesan atau berdiskusi di grup)

# Selamat mengerjakan