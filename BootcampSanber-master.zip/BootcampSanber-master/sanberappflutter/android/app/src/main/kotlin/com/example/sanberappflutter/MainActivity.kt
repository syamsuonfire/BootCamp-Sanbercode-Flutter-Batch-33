package com.example.sanberappflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
